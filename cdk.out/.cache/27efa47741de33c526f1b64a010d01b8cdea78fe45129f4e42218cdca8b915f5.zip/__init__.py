# Dogs Lambda functions
