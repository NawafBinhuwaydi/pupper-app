# Image processing Lambda functions
